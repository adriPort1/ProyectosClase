package appgrafica;

import static appgrafica.AppGrafica.aciertos;
import static appgrafica.AppGrafica.numFallos;
import static appgrafica.AppGrafica.palabra;

public class Ahorca2 extends javax.swing.JFrame {

    public char guion[] = new char[palabra.length()];
    public static char[] letraFallada = new char[10];

    public Ahorca2() {
        initComponents();
        this.setSize(750, 555);
        this.setDefaultCloseOperation(0);
        this.setTitle("Ahorca2");
        primerGuion();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        mostrarFrases = new javax.swing.JTextField();
        mostrarPalabra = new javax.swing.JTextField();
        intentosFallidos = new javax.swing.JTextField();
        letras = new javax.swing.JComboBox<>();
        botonAceptar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        alturaHorca = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        base = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        paloSoga = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        soga = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        cabeza = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        torso = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        brazoDech = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        brazoIzq = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        piernaDech = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));
        piernaIzq = new javax.swing.Box.Filler(new java.awt.Dimension(10, 50), new java.awt.Dimension(10, 50), new java.awt.Dimension(32777, 10));

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mostrarFrases.setBackground(new java.awt.Color(255, 255, 255));
        mostrarFrases.setEnabled(false);

        mostrarPalabra.setBackground(new java.awt.Color(255, 255, 255));
        mostrarPalabra.setEnabled(false);
        mostrarPalabra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarPalabraActionPerformed(evt);
            }
        });

        intentosFallidos.setBackground(new java.awt.Color(255, 255, 255));
        intentosFallidos.setEnabled(false);

        letras.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" }));
        letras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                letrasActionPerformed(evt);
            }
        });

        botonAceptar.setText("Aceptar");
        botonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setEnabled(false);

        alturaHorca.setBackground(new java.awt.Color(0, 0, 0));

        base.setBackground(new java.awt.Color(0, 0, 0));

        paloSoga.setBackground(new java.awt.Color(0, 0, 0));

        soga.setBackground(new java.awt.Color(0, 0, 0));

        cabeza.setBackground(new java.awt.Color(0, 0, 0));

        torso.setBackground(new java.awt.Color(0, 0, 0));

        brazoDech.setBackground(new java.awt.Color(0, 0, 0));

        brazoIzq.setBackground(new java.awt.Color(0, 0, 0));

        piernaDech.setBackground(new java.awt.Color(0, 0, 0));

        piernaIzq.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 107, Short.MAX_VALUE)
                        .addComponent(base, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(brazoIzq, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(cabeza, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(torso, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(piernaIzq, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(27, 27, 27))
                                    .addComponent(soga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(piernaDech, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(brazoDech, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(paloSoga, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(alturaHorca, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(80, 80, 80))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(57, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(paloSoga, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(soga, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(brazoDech, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(brazoIzq, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(72, 72, 72)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(piernaIzq, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(piernaDech, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cabeza, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(torso, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(alturaHorca, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(base, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(119, 119, 119))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(botonAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(letras, 0, 138, Short.MAX_VALUE))
                        .addGap(55, 55, 55))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(mostrarFrases, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(intentosFallidos)
                            .addComponent(mostrarPalabra))
                        .addGap(22, 22, 22)))
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(mostrarPalabra, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(intentosFallidos, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addComponent(letras, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mostrarFrases, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(83, 83, 83))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void primerGuion() {
        /**
         * funcion primer guion primera vez que se muestra la palabra, se mete
         * en un array de guiones
         */
        String conversor = "";
        for (int i = 0; i < palabra.length(); i++) {
            guion[i] = '-';
            conversor += guion[i];
        }
        mostrarPalabra.setText(conversor);
    }

    public boolean Letra(char a) {
        /**
         * funcion letra funcion para saber si la palabra es parte del array de
         * chars creado
         */
        boolean letra = false;
        for (int i = 0; i < 10; i++) {
            if (a == letraFallada[i]) {
                return true;
            }
        }
        return letra;
    }

    public void dibujarPalabra(char a) {
        /**
         * funcion dibujar palabra cada vez que se acierte o falle una letra,
         * esta funcion cambiara los guiones por las letras en las que aparece
         * en la palabra
         */
        String conversor = "";
        for (int i = 0; i < palabra.length(); i++) {
            if (aciertos[i] && palabra.charAt(i) == a) {
                guion[i] = a;
            }
            conversor += guion[i];
        }
        mostrarPalabra.setText(conversor);
    }

    public boolean solucion() {
        /**
         * funcion solucion en la matriz de aciertos creada arriba, ira
         * comprobando que todos false o true, y si todos resultan true, habr�
         * acabado el juego por eso devolveremos en true para el boton
         */
        for (int i = 0; i < aciertos.length; i++) {
            if (!aciertos[i]) {
                return false;
            }
        }
        return true;
    }

    public String mostrarIntentos() {
        /**
         * funcion String palabras con intentos Esta funcion convierte en string
         * los chars con una coma y espacio, lo que hace que se lea y luego
         * devuelve el stream para poder leerlo despues de la conversion
         */
        String palabra = "";
        for (int i = 0; i < 10; i++) {
            if (letraFallada[i] != '\u0000') {
                palabra = palabra + letraFallada[i] + ", ";
            }
        }
        return palabra;
    }

    public void rellenaChar(char a) {
        /**
         * funcion rellenar char aqui rellenamos el array con las nuevas letras,
         * para poder tenerle completo, el array sera de 10 porque son el numero
         * de intentos
         */
        int contador = 0;
        boolean b = false;
        while (!b) {
            if (letraFallada[contador] == '\u0000') {
                letraFallada[contador] = a;
                b = true;
            }
            contador++;
        }
    }
    private void botonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarActionPerformed
        char letraselec = letras.getSelectedItem().toString().charAt(0);
        if (!comprobar(letraselec)) {
            numFallos++;
            if (!Letra(letraselec)) {
                rellenaChar(letraselec);
                intentosFallidos.setText(mostrarIntentos());
            } else {
                intentosFallidos.setText("Esa letra ya fue selecionada");
            }
        } else {
            dibujarPalabra(letraselec);
        }
        mostrarFrases.setText("LLevas " + numFallos + " intentos");
        cuerpo();

        if (solucion() == true) {
            mostrarFrases.setText("Has acertado");
        }

    }//GEN-LAST:event_botonAceptarActionPerformed

    public void cuerpo() {
        /**
         * funcion cuerpo esta funcion es para hacer el cuerpo del ahorcado, con
         * los setbounds de los filer
         */
        switch (numFallos) {
            case 0:
                mostrarFrases.setText("LLevas " + numFallos + " intentos");
                break;
            case 1:
                base.setBounds(90, 325, 300, 15);
                base.setOpaque(true);
                break;
            case 2:
                alturaHorca.setBounds(325, 80, 18, 250);
                alturaHorca.setOpaque(true);
                break;
            case 3:
                paloSoga.setBounds(90, 80, 255, 16);
                paloSoga.setOpaque(true);
                break;
            case 4:
                soga.setBounds(90, 80, 10, 35);
                soga.setOpaque(true);
                break;
            case 5:
                cabeza.setBounds(80, 115, 30, 20);
                cabeza.setOpaque(true);
                break;
            case 6:
                torso.setBounds(90, 130, 10, 50);
                torso.setOpaque(true);
                break;
            case 7:
                brazoDech.setBounds(100, 145, 35, 8);
                brazoDech.setOpaque(true);
                break;
            case 8:
                brazoIzq.setBounds(60, 145, 35, 8);
                brazoIzq.setOpaque(true);
                break;
            case 9:
                piernaDech.setBounds(100, 170, 35, 8);
                piernaDech.setOpaque(true);
                break;
            case 10:
                piernaIzq.setBounds(60, 170, 35, 8);
                piernaIzq.setOpaque(true);
                mostrarFrases.setText("fallaste la palabra " + "' " + palabra + " '");
                break;
            default:
                mostrarFrases.setText("fallaste la palabra " + "' " + palabra + " '");
                break;
        }
    }

    public boolean comprobar(char a) {
        /**
         * funcion comprobar aqui se comprueba que la letra exista, y si lo es,
         * cambia el booleano de su posicion a true
         */
        boolean existeLetra = false;
        for (int i = 0; i < palabra.length(); i++) {
            if (a == palabra.charAt(i)) {
                aciertos[i] = true;
                existeLetra = true;
            }
        }
        return existeLetra;
    }

    private void mostrarPalabraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarPalabraActionPerformed

    }//GEN-LAST:event_mostrarPalabraActionPerformed

    private void letrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_letrasActionPerformed

    }//GEN-LAST:event_letrasActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.Box.Filler alturaHorca;
    private javax.swing.Box.Filler base;
    private javax.swing.JButton botonAceptar;
    private javax.swing.Box.Filler brazoDech;
    private javax.swing.Box.Filler brazoIzq;
    private javax.swing.Box.Filler cabeza;
    private javax.swing.JTextField intentosFallidos;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JComboBox<String> letras;
    private javax.swing.JTextField mostrarFrases;
    private javax.swing.JTextField mostrarPalabra;
    private javax.swing.Box.Filler paloSoga;
    private javax.swing.Box.Filler piernaDech;
    private javax.swing.Box.Filler piernaIzq;
    private javax.swing.Box.Filler soga;
    private javax.swing.Box.Filler torso;
    // End of variables declaration//GEN-END:variables
}
