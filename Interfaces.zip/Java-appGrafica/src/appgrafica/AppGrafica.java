package appgrafica;

import static java.awt.image.ImageObserver.HEIGHT;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AppGrafica {

    public static String palabra = "";
    public static boolean aciertos[];
    public static int numFallos = 0;
    public static final int fallosTotal = 10;
    

    public static void main(String[] args) {
        // ventana por defecto 
        /*MiVentana formulario = new MiVentana();
        formulario.setDefaultCloseOperation((JFrame.EXIT_ON_CLOSE));
        formulario.setVisible(true);
        
        // ventana pidiendo ancho y alto  
        MiVentana formulario2 = new MiVentana(500,300, "titulo");
        formulario2.setDefaultCloseOperation((JFrame.EXIT_ON_CLOSE));
        formulario2.setVisible(true);*/
        // a partir de aqui comentare los metodos que creemos y asi solo cambio 
        //formularioPrueba2();
        // encuesta();
        //gemeraNumeros();
        // espejo()
        // listaNueva()
        //generaNum2
        //  memoria 
        // Ahorca2 
        numJugadores() ;
        Ahorca2 formulario3 = new Ahorca2();
        formulario3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        formulario3.setVisible(true);
        // el ahorcado hace uso del main, asi que pondre a partir de qui cosas del ahorcado 
         aciertos = new boolean[palabra.length()];
        
    }


     public static void numJugadores() {
         /** funcion para el numnero de jugadores
          * funcion que determina si jugaran 1 o mas jugadores, escogiendo la 
          * opcion 1, se escoge una palabra al azar, co la otra uno escoge la 
          * palabra y los demas adivinan
          */
        String entrada;
        do {
            entrada = JOptionPane.showInputDialog(" Cuantos jugadores van a ser? 1 o 2?");
        } while (!entrada.equals("1") && !entrada.equals("2"));
        if (entrada.equals("1")) {
            palabraAzar();
        } else {
            entrada = JOptionPane.showInputDialog("Escoge la palabra para jugar");
            entrada.toLowerCase();
            palabra = entrada;
        }
    }
     
    public static void palabraAzar() {
        /** funcion para escoger la palabra al azar
         * funcion con ficheros para tener las palabras a rellenar, dentro de un 
         * fichero de texto creado fuera del programa que lee con fileReader
         */
        // se usa para ver el fichero 
        final String nomFichero = "C:\\Users\\Programacion\\Desktop\\ahorcadoaleatorio.txt";
        try {
            // leemos el fichero
            FileReader fich = new FileReader(nomFichero);
            // String donde se guaradara el fichero 
            String texto = "";
            // esto es para cuando se desplaze recorriendo el fichero 
            int caracteres = 0;
            int valor = fich.read();
            int letra = 0;
            // para meter en un string para leer en el programa
            while (valor != -1) {
                texto = texto + (char) valor;
                valor = fich.read();
                if ((char) valor == ',') {
                    caracteres++;
                }
                letra++;
            }
            // numero de palabras
            String palabras[] = new String[caracteres + 1];
            // crear matriz de palabras a vacio para meterlas luego 
            for (int i = 0; i < palabras.length; i++) {
                palabras[i] = "";
            }
            fich = new FileReader(nomFichero);
            int posiciones = 0;
            valor = fich.read();
            //while para meter las palabras en un nuevo string esta vez en array
            while (valor != -1) {
                if ((char) valor == ',') {
                    posiciones++;
                } else {
                    palabras[posiciones] += (char) valor;
                }
                valor = fich.read();
                // numero aleatorio para escoger una palabra 
            }
            int numPalabra = (int) (Math.random() * palabras.length);
            palabra = palabras[numPalabra];
        } catch (IOException e) {
            System.out.println("Fichero inexistente o ruta incorrecta" + e);
        }

    }
          
}
