
package appgrafica;

import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class memoria extends javax.swing.JFrame {
   public static JPanel copia=new JPanel();
   public static JLabel letra=new JLabel();
   public static boolean muestra=false;
    public memoria()  {
        initComponents();
        this.setSize(530, 430);
        this.setTitle("Juego de memoria");
        this.setDefaultCloseOperation(0);
         
        JOptionPane.showConfirmDialog(null, "� Quieres jugar ?", "anuncio", WIDTH, HEIGHT);
        mostrarVisible();
        mostrarOpaco();
        
    }
    
   /* public static void pausa(){
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(memoria.class.getName()).log(Level.SEVERE, null, ex);
        }
        Esta funcion para congelar la iba a usar para mostrar el panel pero al final se hizo mejor 
        con el timer y timertask
    }*/
  public static void comprobar(JLabel a, JPanel b){
   if (!muestra){
               muestra=true;
               copia=b;
               letra=a;
           } else if(muestra && letra.getText()!=a.getText()){
               muestra=false;
               a.setVisible(false);
               letra.setVisible(false);
           } else {
               a.setVisible(true);
               muestra=false;
           }
  
  }
public final void mostrarVisible(){
        a11.setVisible(true);
        a12.setVisible(true);
        b11.setVisible(true);
        b12.setVisible(true);
        c11.setVisible(true);
        c12.setVisible(true);
        d11.setVisible(true);
        d12.setVisible(true);
        e11.setVisible(true);
        e12.setVisible(true);
        f11.setVisible(true);
        f12.setVisible(true);
       
}

public final void mostrarOpaco(){
    Timer tempo = new Timer();
        TimerTask tarea= new TimerTask() {
        public void run(){
        a11.setVisible(false);
        a12.setVisible(false);
        b11.setVisible(false);
        b12.setVisible(false);
        c11.setVisible(false);
        c12.setVisible(false);
        d11.setVisible(false);
        d12.setVisible(false);
        e11.setVisible(false);
        e12.setVisible(false);
        f11.setVisible(false);
        f12.setVisible(false);
        }
        };  
        tempo.schedule(tarea,3000);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        a1 = new javax.swing.JPanel();
        a11 = new javax.swing.JLabel();
        b1 = new javax.swing.JPanel();
        b11 = new javax.swing.JLabel();
        f1 = new javax.swing.JPanel();
        f11 = new javax.swing.JLabel();
        e1 = new javax.swing.JPanel();
        e11 = new javax.swing.JLabel();
        d1 = new javax.swing.JPanel();
        d11 = new javax.swing.JLabel();
        b2 = new javax.swing.JPanel();
        b12 = new javax.swing.JLabel();
        c1 = new javax.swing.JPanel();
        c11 = new javax.swing.JLabel();
        c2 = new javax.swing.JPanel();
        c12 = new javax.swing.JLabel();
        a2 = new javax.swing.JPanel();
        a12 = new javax.swing.JLabel();
        e2 = new javax.swing.JPanel();
        e12 = new javax.swing.JLabel();
        d2 = new javax.swing.JPanel();
        d12 = new javax.swing.JLabel();
        f2 = new javax.swing.JPanel();
        f12 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("memoria");

        a1.setBackground(new java.awt.Color(153, 153, 255));
        a1.setMaximumSize(new java.awt.Dimension(95, 95));
        a1.setMinimumSize(new java.awt.Dimension(95, 95));
        a1.setPreferredSize(new java.awt.Dimension(95, 95));
        a1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                a1MouseClicked(evt);
            }
        });
        a1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                a1PropertyChange(evt);
            }
        });

        a11.setForeground(new java.awt.Color(0, 0, 0));
        a11.setText("A");
        a11.setToolTipText("");
        a11.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                a11ComponentHidden(evt);
            }
        });

        javax.swing.GroupLayout a1Layout = new javax.swing.GroupLayout(a1);
        a1.setLayout(a1Layout);
        a1Layout.setHorizontalGroup(
            a1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, a1Layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addComponent(a11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );
        a1Layout.setVerticalGroup(
            a1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(a1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(a11, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        b1.setBackground(new java.awt.Color(153, 153, 255));
        b1.setMaximumSize(new java.awt.Dimension(95, 95));
        b1.setMinimumSize(new java.awt.Dimension(95, 95));
        b1.setPreferredSize(new java.awt.Dimension(95, 95));
        b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b1MouseClicked(evt);
            }
        });

        b11.setForeground(new java.awt.Color(0, 0, 0));
        b11.setText("B");

        javax.swing.GroupLayout b1Layout = new javax.swing.GroupLayout(b1);
        b1.setLayout(b1Layout);
        b1Layout.setHorizontalGroup(
            b1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(b1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(b11, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        b1Layout.setVerticalGroup(
            b1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(b1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(b11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        f1.setBackground(new java.awt.Color(153, 153, 255));
        f1.setMaximumSize(new java.awt.Dimension(95, 95));
        f1.setMinimumSize(new java.awt.Dimension(95, 95));
        f1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                f1MouseClicked(evt);
            }
        });

        f11.setForeground(new java.awt.Color(0, 0, 0));
        f11.setText("F");

        javax.swing.GroupLayout f1Layout = new javax.swing.GroupLayout(f1);
        f1.setLayout(f1Layout);
        f1Layout.setHorizontalGroup(
            f1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, f1Layout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addComponent(f11)
                .addGap(44, 44, 44))
        );
        f1Layout.setVerticalGroup(
            f1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(f1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(f11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        e1.setBackground(new java.awt.Color(153, 153, 255));
        e1.setMaximumSize(new java.awt.Dimension(95, 95));
        e1.setMinimumSize(new java.awt.Dimension(95, 95));
        e1.setPreferredSize(new java.awt.Dimension(95, 95));
        e1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                e1MouseClicked(evt);
            }
        });

        e11.setForeground(new java.awt.Color(0, 0, 0));
        e11.setText("E");

        javax.swing.GroupLayout e1Layout = new javax.swing.GroupLayout(e1);
        e1.setLayout(e1Layout);
        e1Layout.setHorizontalGroup(
            e1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(e1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(e11)
                .addContainerGap(45, Short.MAX_VALUE))
        );
        e1Layout.setVerticalGroup(
            e1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(e1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(e11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        d1.setBackground(new java.awt.Color(153, 153, 255));
        d1.setMaximumSize(new java.awt.Dimension(95, 95));
        d1.setMinimumSize(new java.awt.Dimension(95, 95));
        d1.setPreferredSize(new java.awt.Dimension(95, 95));
        d1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                d1MouseClicked(evt);
            }
        });

        d11.setForeground(new java.awt.Color(0, 0, 0));
        d11.setText("D");

        javax.swing.GroupLayout d1Layout = new javax.swing.GroupLayout(d1);
        d1.setLayout(d1Layout);
        d1Layout.setHorizontalGroup(
            d1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(d1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(d11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        d1Layout.setVerticalGroup(
            d1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(d1Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(d11)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        b2.setBackground(new java.awt.Color(153, 153, 255));
        b2.setMaximumSize(new java.awt.Dimension(95, 95));
        b2.setMinimumSize(new java.awt.Dimension(95, 95));
        b2.setPreferredSize(new java.awt.Dimension(95, 95));
        b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b2MouseClicked(evt);
            }
        });

        b12.setForeground(new java.awt.Color(0, 0, 0));
        b12.setText("B");

        javax.swing.GroupLayout b2Layout = new javax.swing.GroupLayout(b2);
        b2.setLayout(b2Layout);
        b2Layout.setHorizontalGroup(
            b2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, b2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(b12, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        b2Layout.setVerticalGroup(
            b2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(b2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(b12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        c1.setBackground(new java.awt.Color(153, 153, 255));
        c1.setMaximumSize(new java.awt.Dimension(95, 95));
        c1.setMinimumSize(new java.awt.Dimension(95, 95));
        c1.setPreferredSize(new java.awt.Dimension(95, 95));
        c1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                c1MouseClicked(evt);
            }
        });

        c11.setForeground(new java.awt.Color(0, 0, 0));
        c11.setText("C");

        javax.swing.GroupLayout c1Layout = new javax.swing.GroupLayout(c1);
        c1.setLayout(c1Layout);
        c1Layout.setHorizontalGroup(
            c1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(c1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(c11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        c1Layout.setVerticalGroup(
            c1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(c1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(c11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        c2.setBackground(new java.awt.Color(153, 153, 255));
        c2.setMaximumSize(new java.awt.Dimension(95, 95));
        c2.setMinimumSize(new java.awt.Dimension(95, 95));
        c2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                c2MouseClicked(evt);
            }
        });

        c12.setForeground(new java.awt.Color(0, 0, 0));
        c12.setText("C");

        javax.swing.GroupLayout c2Layout = new javax.swing.GroupLayout(c2);
        c2.setLayout(c2Layout);
        c2Layout.setHorizontalGroup(
            c2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(c2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(c12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        c2Layout.setVerticalGroup(
            c2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(c2Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(c12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        a2.setBackground(new java.awt.Color(153, 153, 255));
        a2.setMaximumSize(new java.awt.Dimension(95, 95));
        a2.setMinimumSize(new java.awt.Dimension(95, 95));
        a2.setPreferredSize(new java.awt.Dimension(95, 95));
        a2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                a2MouseClicked(evt);
            }
        });

        a12.setForeground(new java.awt.Color(0, 0, 0));
        a12.setText("A");
        a12.setToolTipText("");

        javax.swing.GroupLayout a2Layout = new javax.swing.GroupLayout(a2);
        a2.setLayout(a2Layout);
        a2Layout.setHorizontalGroup(
            a2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(a2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(a12, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );
        a2Layout.setVerticalGroup(
            a2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(a2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(a12)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        e2.setBackground(new java.awt.Color(153, 153, 255));
        e2.setMaximumSize(new java.awt.Dimension(95, 95));
        e2.setMinimumSize(new java.awt.Dimension(95, 95));
        e2.setPreferredSize(new java.awt.Dimension(95, 95));
        e2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                e2MouseClicked(evt);
            }
        });

        e12.setForeground(new java.awt.Color(0, 0, 0));
        e12.setText("E");

        javax.swing.GroupLayout e2Layout = new javax.swing.GroupLayout(e2);
        e2.setLayout(e2Layout);
        e2Layout.setHorizontalGroup(
            e2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(e2Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(e12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        e2Layout.setVerticalGroup(
            e2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, e2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(e12)
                .addGap(38, 38, 38))
        );

        d2.setBackground(new java.awt.Color(153, 153, 255));
        d2.setMaximumSize(new java.awt.Dimension(95, 95));
        d2.setMinimumSize(new java.awt.Dimension(95, 95));
        d2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                d2MouseClicked(evt);
            }
        });

        d12.setForeground(new java.awt.Color(0, 0, 0));
        d12.setText("D");

        javax.swing.GroupLayout d2Layout = new javax.swing.GroupLayout(d2);
        d2.setLayout(d2Layout);
        d2Layout.setHorizontalGroup(
            d2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(d2Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(d12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        d2Layout.setVerticalGroup(
            d2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(d2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(d12)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        f2.setBackground(new java.awt.Color(153, 153, 255));
        f2.setMaximumSize(new java.awt.Dimension(95, 95));
        f2.setMinimumSize(new java.awt.Dimension(95, 95));
        f2.setPreferredSize(new java.awt.Dimension(95, 95));
        f2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                f2MouseClicked(evt);
            }
        });

        f12.setForeground(new java.awt.Color(0, 0, 0));
        f12.setText("F");

        javax.swing.GroupLayout f2Layout = new javax.swing.GroupLayout(f2);
        f2.setLayout(f2Layout);
        f2Layout.setHorizontalGroup(
            f2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(f2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(f12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        f2Layout.setVerticalGroup(
            f2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(f2Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(f12)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(d1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(a1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(c2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(a2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(b2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(b1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(e2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(f1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(c1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(f2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(e1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(d2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(98, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(e1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(c1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(b1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(a1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(d1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(b2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(6, 6, 6))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(f2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(d2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(a2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(e2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(c2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(109, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void a11ComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_a11ComponentHidden
 
    }//GEN-LAST:event_a11ComponentHidden

    private void a1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a1MouseClicked
           a11.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=a1;
               letra=a11;
           } else if(muestra && letra.getText()!=a11.getText()){
               muestra=false;
               a11.setVisible(false);
               letra.setVisible(false);
           } else {
               a11.setVisible(true);
               muestra=false;
               
           }
    }//GEN-LAST:event_a1MouseClicked

    private void b1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MouseClicked
          b11.setVisible(true); 
          if (!muestra){
               muestra=true;
               copia=b1;
               letra=b11;
           } else if(muestra && letra.getText()!=b11.getText()){
               muestra=false;
               b11.setVisible(false);
               letra.setVisible(false);
           } else {
               b11.setVisible(true);
               muestra=false;
              
           }
    }//GEN-LAST:event_b1MouseClicked

    private void c1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c1MouseClicked
          c11.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=c1;
               letra=c11;
           } else if(muestra && letra.getText()!=c11.getText()){
               muestra=false;
               c11.setVisible(false);
               letra.setVisible(false);
           } else {
               c11.setVisible(true);
               muestra=false;
             
           }
    }//GEN-LAST:event_c1MouseClicked

    private void e1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e1MouseClicked
        e11.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=e1;
               letra=e11;
           } else if(muestra && letra.getText()!=e11.getText()){
               muestra=false;
               e11.setVisible(false);
               letra.setVisible(false);
           } else {
               e11.setVisible(true);
               muestra=false;
           }
    }//GEN-LAST:event_e1MouseClicked

    private void d1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d1MouseClicked
          d11.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=d1;
               letra=d11;
           } else if(muestra && letra.getText()!=d11.getText()){
               muestra=false;
               d11.setVisible(false);
               letra.setVisible(false);
           } else {
               d11.setVisible(true);
               muestra=false;
               
           }
    }//GEN-LAST:event_d1MouseClicked

    private void b2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b2MouseClicked
          b12.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=b2;
               letra=b12;
           } else if(muestra && letra.getText()!=b11.getText()){
               muestra=false;
               b12.setVisible(false);
               letra.setVisible(false);
           } else {
               b12.setVisible(true);
               muestra=false;
             
           }
    }//GEN-LAST:event_b2MouseClicked

    private void f1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f1MouseClicked
         f11.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=f1;
               letra=f11;
           } else if(muestra && letra.getText()!=f11.getText()){
               muestra=false;
               f11.setVisible(false);
               letra.setVisible(false);
           } else {
               f11.setVisible(true);
               muestra=false;
              
           }
    }//GEN-LAST:event_f1MouseClicked

    private void f2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f2MouseClicked
        f12.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=f2;
               letra=f12;
           } else if(muestra && letra.getText()!=f12.getText()){
               muestra=false;
               f12.setVisible(false);
               letra.setVisible(false);
           } else {
               f12.setVisible(true);
               muestra=false;
          
           }
    }//GEN-LAST:event_f2MouseClicked

    private void c2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c2MouseClicked
         c12.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=c2;
               letra=c12;
           } else if(muestra && letra.getText()!=c12.getText()){
               muestra=false;
               c12.setVisible(false);
               letra.setVisible(false);
           } else {
               c12.setVisible(true);
               muestra=false;
           }
    }//GEN-LAST:event_c2MouseClicked

    private void a2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a2MouseClicked
         a12.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=a2;
               letra=a12;
           } else if(muestra && letra.getText()!=a12.getText()){
               muestra=false;
               a12.setVisible(false);
               letra.setVisible(false);
           } else {
               a12.setVisible(true);
               muestra=false;
        
           }
    }//GEN-LAST:event_a2MouseClicked

    private void e2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e2MouseClicked
         e12.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=e2;
               letra=e12;
           } else if(muestra && letra.getText()!=e12.getText()){
               muestra=false;
               e12.setVisible(false);
               letra.setVisible(false);
           } else {
               e12.setVisible(true);
               muestra=false;
         
           }
    }//GEN-LAST:event_e2MouseClicked

    private void d2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d2MouseClicked
         d12.setVisible(true);   
           if (!muestra){
               muestra=true;
               copia=d2;
               letra=d12;
           } else if(muestra && letra.getText()!=d12.getText()){
               muestra=false;
               d12.setVisible(false);
               letra.setVisible(false);
           } else {
               d12.setVisible(true);
               muestra=false;
           
           }
    }//GEN-LAST:event_d2MouseClicked

    private void a1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_a1PropertyChange
        
    }//GEN-LAST:event_a1PropertyChange

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel a1;
    private javax.swing.JLabel a11;
    private javax.swing.JLabel a12;
    private javax.swing.JPanel a2;
    private javax.swing.JPanel b1;
    private javax.swing.JLabel b11;
    private javax.swing.JLabel b12;
    private javax.swing.JPanel b2;
    private javax.swing.JPanel c1;
    private javax.swing.JLabel c11;
    private javax.swing.JLabel c12;
    private javax.swing.JPanel c2;
    private javax.swing.JPanel d1;
    private javax.swing.JLabel d11;
    private javax.swing.JLabel d12;
    private javax.swing.JPanel d2;
    private javax.swing.JPanel e1;
    private javax.swing.JLabel e11;
    private javax.swing.JLabel e12;
    private javax.swing.JPanel e2;
    private javax.swing.JPanel f1;
    private javax.swing.JLabel f11;
    private javax.swing.JLabel f12;
    private javax.swing.JPanel f2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
}
